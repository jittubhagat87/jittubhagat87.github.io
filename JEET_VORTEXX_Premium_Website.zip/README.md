# JEET VORTEXX Website

Free one-page portfolio website.

## Publish free with GitHub Pages
1. Create a GitHub account.
2. Create a new public repository named `jeetvortexx.github.io` (replace with your GitHub username).
3. Upload `index.html`.
4. Open Settings → Pages → Deploy from branch → main → /root.
5. Your site will be available at `https://YOURUSERNAME.github.io/`.

Before publishing, replace the WhatsApp link and email in `index.html`, and replace the portfolio placeholders with your own videos/images.
